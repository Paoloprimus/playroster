# 🏟️ PlayRoster

PlayRoster è una web app per gestire in modo realistico e strategico il fantacalcio.